// js/score_input_criteria.js
// STEP B-1：評価基準のロード＋ヘッダ生成モジュール

import {
  doc,
  getDoc,
} from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";
import { activateQuotaErrorState } from "./quota_banner.js";

import { getBaseColumns } from "./score_input_columns.js";

/**
 * 評価基準状態
 */
export function createCriteriaState() {
  return {
    items: [],
    normalizedWeights: [],
    rawTotal: 0,
    ready: false,
    maxByIndex: [],
  };
}

/**
 * 割合を正規化
 */
export function normalizeWeights(weights) {
  const total = weights.reduce((s, v) => s + (Number(v) || 0), 0);

  if (total === 0) {
    return {
      normalized: weights.map(() => 0),
      rawTotal: 0,
    };
  }

  if (total >= 99 && total <= 101) {
    const factor = 100 / total;
    return {
      normalized: weights.map((v) => (Number(v) || 0) * factor),
      rawTotal: total,
    };
  }

  return { normalized: weights.slice(), rawTotal: total };
}

/**
 * Firestore から評価基準を取得
 */
export async function loadCriteria(db, year, subjectId, criteriaState) {
  criteriaState.items = [];
  criteriaState.normalizedWeights = [];
  criteriaState.rawTotal = 0;
  criteriaState.maxByIndex = [];
  criteriaState.ready = false;

  if (!subjectId) return;

  const colName = `evaluationCriteria_${year}`;
  const ref = doc(db, colName, subjectId);
    let snap;
    try {
      snap = await getDoc(ref);
    } catch (err) {
      if (err.code === "resource-exhausted" || String(err.message).includes("Quota exceeded")) {
        activateQuotaErrorState();
        throw err;
      } else {
        throw err;
      }
    }
  if (!snap.exists()) return;

  const data = snap.data() || {};
  const items = data.items || [];

  // --- adjustPoint, useAdjustPoint を state に格納 ---
  criteriaState.adjustPoint = (typeof data.adjustPoint === 'number' || data.adjustPoint === null) ? data.adjustPoint : null;
  criteriaState.useAdjustPoint = (typeof data.useAdjustPoint === 'boolean') ? data.useAdjustPoint : false;

const mapped = items.map((it) => {
  const percent = Number(it.percent ?? 0);

  // Firestore（evaluation.html）が保存しているのは maxScore
  const maxScore = Number(it.maxScore);

  let max;

  // ① Firestore に maxScore が数値で入っている（＝「割合と同じ」など）
  if (Number.isFinite(maxScore) && maxScore > 0) {
    max = maxScore;

  // ② 旧互換：it.max が数値で入っている（過去データ救済）
  } else if (Number.isFinite(Number(it.max)) && Number(it.max) > 0) {
    max = Number(it.max);

  // ③ 旧互換：it.max が "percent"/"same"（過去データ救済）
  } else if (it.max === "same" || it.max === "percent") {
    max = percent;

  // ④ それ以外（maxScore 無し＝100点満点扱い）
  } else {
    max = 100;
  }

  return {
    name: it.name || "",
    percent,
    max,
  };
});



const { normalized, rawTotal } = normalizeWeights(
  mapped.map((i) => i.percent)
);

  criteriaState.items = mapped;
  criteriaState.normalizedWeights = normalized;
  criteriaState.rawTotal = rawTotal;
  criteriaState.maxByIndex = mapped.map((item) => item.max);
  criteriaState.ready = true;
  if (typeof window !== "undefined") {
    window.enableScoreInputs?.();
  }
}

/**
 * 成績表ヘッダ描画（項目ごとラベル表示）
 */
export function renderTableHeader(headerRow, criteriaState) {
  headerRow.innerHTML = "";

  // ===== ベース列（学籍番号〜氏名）=====
  const baseCols = getBaseColumns();

  baseCols.forEach(col => {
    const th = document.createElement("th");
    th.textContent = col.label;
    th.style.textAlign = col.align;

    if (col.width) th.style.width = col.width + "px";
    if (col.minWidth) th.style.minWidth = col.minWidth + "px";

    if (col.key === "name") {
      th.classList.add("student-name");
    }

    headerRow.appendChild(th);
  });

  // ===== 評価基準列 =====
  const items = criteriaState.items || [];

  if (!items.length) {
    const th = document.createElement("th");
    th.textContent = "評価項目";
    headerRow.appendChild(th);
  } else {
    items.forEach(critItem => {
      const th = document.createElement("th");
      th.classList.add("criteria-th");

      const title = document.createElement("div");
      title.className = "criteria-title";
      title.textContent = String(critItem.name ?? "");
      th.appendChild(title);

      const percent = Number(critItem?.percent);
      const percentLine = document.createElement("div");
      percentLine.className = "criteria-percentline";
      percentLine.textContent = Number.isFinite(percent) ? `(${percent}%)` : "";
      th.appendChild(percentLine);

      const max = Number(critItem?.max);
      const maxLine = document.createElement("div");
      maxLine.className = "criteria-maxline";
      maxLine.textContent = Number.isFinite(max) ? `(${max}点満点)` : "";
      th.appendChild(maxLine);

      headerRow.appendChild(th);
    });
  }

  // ===== 最終成績 =====
  const finalTh = document.createElement("th");
  finalTh.textContent = "最終成績";
  finalTh.classList.add("final-score");
  headerRow.appendChild(finalTh);
}

/**
 * 評価基準が「単一・100%」かどうかを判定
 * - 評価項目が1つ
 * - 割合が100%
 *
 * この場合：
 *   自動換算（0〜100）でも結果が同じため、貼り付け確認モーダルは不要。
 *
 * @param {{ items:any[] }} criteriaState
 * @returns {boolean}
 */
export function isSingle100PercentCriteria(criteriaState) {
  if (!criteriaState || !Array.isArray(criteriaState.items)) return false;
  if (criteriaState.items.length !== 1) return false;

  const percent = Number(criteriaState.items[0]?.percent || 0);
  return percent === 100;
}
