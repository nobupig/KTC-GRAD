export const CURRENT_YEAR = "2025";
